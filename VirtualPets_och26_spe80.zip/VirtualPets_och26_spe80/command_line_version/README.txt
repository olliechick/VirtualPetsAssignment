VirtualPetsAssignment

=== Command Line Version ===
To run the command line version use the command below from the command line of your choice.

java -jar VirtualPetsCLI.jar 
