# VirtualPetsAssignment

## Command Line Version
To run the command line version use the command
``java -jar VirtualPetsCLI.jar``
from the command line of your choice
