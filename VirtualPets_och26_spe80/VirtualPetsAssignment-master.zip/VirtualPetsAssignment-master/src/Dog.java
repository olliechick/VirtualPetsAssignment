/**
 * Dog, a type of pet.
 * @author Ollie Chick
 *
 */
public class Dog extends Pet {
    /**
     * Constructs a .
     */
    public Dog() {
        super("dog");
    }
}
