/**
 * Goat, a type of pet.
 * @author Ollie Chick
 *
 */
public class Goat extends Pet {
    /**
     * Constructs a goat.
     */
    public Goat() {
        super("goat");
    }
}
