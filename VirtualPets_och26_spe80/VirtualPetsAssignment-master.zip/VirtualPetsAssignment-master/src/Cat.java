/**
 * Cat, a type of pet.
 * @author Ollie Chick
 *
 */
public class Cat extends Pet {
    /**
     * Constructs a cat.
     */
    public Cat() {
        super("cat");
    }
}
